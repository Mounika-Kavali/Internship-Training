import React, { Component } from 'react'
 class AboutUs extends Component {
  render() {
    return (
      <div>AboutUs</div>
    )
  }
}

export default AboutUs